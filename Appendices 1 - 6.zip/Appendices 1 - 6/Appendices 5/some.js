let Sum =( a,b) => a+b;
console.log(Sum(3,4));